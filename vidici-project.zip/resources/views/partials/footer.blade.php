<footer id="contact" class="bg-[#0b1120] pt-16 pb-12 relative overflow-hidden">
    <div class="absolute bottom-0 right-10 opacity-80 pointer-events-none">
        <svg width="150" height="150" viewBox="0 0 100 100" fill="none" stroke="#ef4444" stroke-width="4">
            <line x1="40" y1="100" x2="100" y2="40"></line>
            <line x1="20" y1="100" x2="100" y2="20"></line>
            <line x1="0" y1="100" x2="100" y2="0"></line>
        </svg>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-10 mb-16 border-b border-gray-800 pb-16">
            
            <div>
                <h4 class="text-white font-bold mb-6">Resources</h4>
                <ul class="space-y-4 text-sm text-gray-500">
                    <li><a href="#" class="hover:text-white transition">Showcase [cite: 27]</a></li>
                    <li><a href="#" class="hover:text-white transition">Portfolio [cite: 82]</a></li>
                    <li><a href="#" class="hover:text-white transition">Blog</a></li>
                    <li><a href="#" class="hover:text-white transition">GitHub</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-bold mb-6">Solutions</h4>
                <ul class="space-y-4 text-sm text-gray-500">
                    <li><a href="#" class="hover:text-white transition">Managed Ops [cite: 6]</a></li>
                    <li><a href="#" class="hover:text-white transition">Custom Apps [cite: 6]</a></li>
                    <li><a href="#" class="hover:text-white transition">Odoo Platform [cite: 8]</a></li>
                    <li><a href="#" class="hover:text-white transition">Banking [cite: 6]</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-bold mb-6">Company</h4>
                <ul class="space-y-4 text-sm text-gray-500">
                    <li><a href="#" class="hover:text-white transition">About [cite: 19]</a></li>
                    <li><a href="#" class="hover:text-white transition">Careers</a></li>
                    <li><a href="#" class="hover:text-white transition">Contact Us [cite: 27]</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-bold mb-6">Legal</h4>
                <ul class="space-y-4 text-sm text-gray-500">
                    <li><a href="#" class="hover:text-white transition">Terms of Service</a></li>
                    <li><a href="#" class="hover:text-white transition">Privacy Policy</a></li>
                    <li><a href="#" class="hover:text-white transition">DPA</a></li>
                </ul>
            </div>

            <div class="col-span-2 md:col-span-4 lg:col-span-1">
                <h4 class="text-white font-bold mb-6">Hubungi Kami [cite: 27]</h4>
                <p class="text-sm text-gray-500 mb-2">info@vidici.id [cite: 2]</p>
                <p class="text-sm text-gray-500 mb-4">+62 811-1170-196 [cite: 27]</p>
                <form class="flex mt-4">
                    <input type="email" placeholder="Enter your email" class="w-full bg-[#161b2a] border border-gray-700 text-white px-3 py-2 rounded-l-md outline-none focus:border-[#6366f1] text-sm">
                    <button type="button" class="bg-[#6366f1] px-4 py-2 text-white font-bold text-sm rounded-r-md hover:bg-[#4f46e5] transition">
                        Subscribe
                    </button>
                </form>
            </div>
        </div>

        <div class="flex flex-col md:flex-row justify-between items-center gap-4">
            <p class="text-gray-500 text-sm">© 2025 PT Vidya Diginara Cipta. All rights reserved. [cite: 3]</p>
            <div class="flex space-x-4">
                <a href="#" class="text-gray-500 hover:text-white"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg></a>
                <a href="#" class="text-gray-500 hover:text-white"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
            </div>
        </div>
    </div>
</footer>